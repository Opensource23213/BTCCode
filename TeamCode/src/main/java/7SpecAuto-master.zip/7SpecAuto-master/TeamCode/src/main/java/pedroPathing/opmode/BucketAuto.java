package pedroPathing.opmode;

import static java.lang.Math.abs;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.arcrobotics.ftclib.controller.PIDController;
import com.pedropathing.follower.Follower;
import com.pedropathing.localization.Pose;
import com.pedropathing.pathgen.BezierCurve;
import com.pedropathing.pathgen.BezierLine;
import com.pedropathing.pathgen.Path;
import com.pedropathing.pathgen.PathChain;
import com.pedropathing.pathgen.Point;
import com.pedropathing.util.Constants;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.rev.RevTouchSensor;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.Telemetry;

import java.util.concurrent.TimeUnit;

import pedroPathing.constants.AltFConstants;
import pedroPathing.constants.BucketConstants;
import pedroPathing.constants.FConstants;
import pedroPathing.constants.LConstants;


/**
 * This is the StraightBackAndForth autonomous OpMode. It runs the robot in a specified distance
 * straight forward. On reaching the end of the forward Path, the robot runs the backward Path the
 * same distance back to the start. Rinse and repeat! This is good for testing a variety of Vectors,
 * like the drive Vector, the translational Vector, and the heading Vector. Remember to test your
 * tunings on CurvedBackAndForth as well, since tunings that work well for straight lines might
 * have issues going in curves.
 *
 * @author Anyi Lin - 10158 Scott's Bots
 * @author Aaron Yang - 10158 Scott's Bots
 * @author Harrison Womack - 10158 Scott's Bots
 * @version 1.0, 3/12/2024
 */
@Config
@Autonomous (name = "BucketAuto", group = "AAA", preselectTeleOp = "BucketTele")
public class BucketAuto extends OpMode {
    private Telemetry telemetryA;

    public static double DISTANCE = 40;

    private double forward = 1;

    private Follower follower;

    private Path forwards;
    private Path backwards;
    private Path push1;
    private Path push1ish;
    private Path push1ish2;
    private Path push2;
    private Path push2ish;
    private Path push3;
    private Path push3ish;
    private Path score1;
    private Path score2;
    private Path score2ish;
    private Path score3;
    private Path score3ish;
    private Path score4;
    private Path score4ish;
    private Path score5;
    private Path score5ish;
    private Path comeback1;
    private Path comeback1ish;
    private Path comeback1ish2;
    private Path comeback2;
    private Path comeback2ish;
    private Path comeback2ish2;
    private Path comeback3;
    private Path comeback3ish;
    private Path comeback3ish2;
    private PathChain MainCode;
    private PIDController controller;
    private PIDController armcontroller;

    public static double p = 0.004, i = 0, d = 0;

    public static double f = 0.01;

    public static int slidestarget = 0;
    public static double armp = 0.01, armi = 0, armd = 0;

    public static double armf = 0.01;

    public static int armtarget = 0;
    public double a = 0;


    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    private ElapsedTime drivetime = new ElapsedTime();

    private DcMotor slides = null;
    private DcMotor Arm1 = null;
    private DcMotor Arm2 = null;
    private AnalogInput ArmPos = null;
    private Servo wristy = null;
    private Servo twisty = null;
    public spin gripspinny;

    double mode = 1;
    double basketmove =1;
    double slideratio = 2;
    double slideticks = 103.8 * slideratio / 4.75;
    double armticks = 8192 / 360;
    double toplimit = 18.6;

    double bottomlimit = .25;
    double slidebasket = 1600 ;
    double armbasket = 2000;
    double twistbasket = .5;
    double wristbasket = .6;
    double slidespecimen = .5;
    double armspecimen = 1380 ;
    double wristspecimen = .3;
    double twistspecimen = .5;
    double armspecimenpickup = 60;
    double wristspecimenpickup = .51;
    double ticks = .002866;
    double xpress = 1;
    public double start = 0;
    public IMU imu = null;
    public DcMotor front_left = null;
    public DcMotor rear_left = null;
    public DcMotor front_right = null;
    public DcMotor rear_right = null;
    public double apress = 1;
    double just = 0;
    public RevTouchSensor limitfront;
    public RevTouchSensor limitfront2;
    public DigitalChannel limitwrist1;
    public double r1press = 1;
    public double armPose = 0;
    double slidesPose = 0;
    double wristpose = .5;
    double twistpose = .5;
    public double count = 1;
    public double flippose = 0;
    public flippy flip;
    public double flipsafe = 1;
    public double dropping = 1;
    public double special_pick = 1;
    public double first_score = 1;
    public double wrist_at = 0;
    public AnalogInput wristencoder;
    public double stopped = 1;
    public DigitalChannel limitslide;
    public boolean slidelimit = true;
    public double bucket = 1;
    public Limelight3A limelight;
    public double ypress = 1;
    public Servo light = null;
    public boolean look = false;
    public double breaak = 1;
    public boolean locked = false;
    public double tx = 0;
    public double ty = 0;
    public double mod = 0;
    public double ymod = 0;
    public boolean autotwist = true;
    public double good = 1;
    public double shift = 0;



    /**
     * This initializes the Follower and creates the forward and backward Paths. Additionally, this
     * initializes the FTC Dashboard telemetry.
     */
    @Override
    public void init() {
        Constants.setConstants(BucketConstants.class, LConstants.class);
        follower = new Follower(hardwareMap);
        limitslide = hardwareMap.get(DigitalChannel.class, "limitslide");
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.setPollRateHz(100); // This sets how often we ask Limelight for data (100 times per second)
        limelight.start(); // This tells Limelight to start looking!
        limelight.pipelineSwitch(4);
        flip = new flippy();
        score1 = new Path(new BezierCurve(new Point(7.2, 6.5, Point.CARTESIAN), new Point(11.1, 13, Point.CARTESIAN), new Point(5.8, 18.8, Point.CARTESIAN)));
        score1.setLinearHeadingInterpolation(0, Math.toRadians(317));
        push1 = new Path(new BezierLine(new Point(5.8, 18.8, Point.CARTESIAN), new Point(14, 19.0001, Point.CARTESIAN)));
        push1.setConstantHeadingInterpolation(Math.toRadians(-23));
        push2 = new Path(new BezierLine(new Point(5.8, 18.8, Point.CARTESIAN), new Point(14, 19, Point.CARTESIAN)));
        push2.setConstantHeadingInterpolation(Math.toRadians(23));
        push3 = new Path(new BezierLine(new Point(5.8, 18.8, Point.CARTESIAN), new Point(14, 19, Point.CARTESIAN)));
        push3.setConstantHeadingInterpolation(Math.toRadians(0));
        score2 = new Path(new BezierCurve(new Point(15, 20, Point.CARTESIAN), new Point(11.1, 19, Point.CARTESIAN), new Point(5.8, 18.8, Point.CARTESIAN)));
        score2.setConstantHeadingInterpolation(Math.toRadians(317));
        comeback2 = new Path(new BezierCurve(new Point(5.8, 18.8, Point.CARTESIAN), new Point(20, 15, Point.CARTESIAN),new Point(30, 13, Point.CARTESIAN),new Point(40, 10, Point.CARTESIAN),new Point(55.7, 5, Point.CARTESIAN), new Point(55.7, -15.2, Point.CARTESIAN)));
        score3 = new Path(new BezierCurve(new Point(51.7, -13.4, Point.CARTESIAN),new Point(48, -5, Point.CARTESIAN),new Point(40, 5, Point.CARTESIAN),new Point(30, 13, Point.CARTESIAN), new Point(20, 15.8, Point.CARTESIAN), new Point(5.8, 18.8, Point.CARTESIAN)));
        score3.setConstantHeadingInterpolation(Math.toRadians(317));
        flip.initialize();
        telemetryA = new MultipleTelemetry(this.telemetry, FtcDashboard.getInstance().getTelemetry());
        telemetryA.addLine("This will run the robot in a straight line going " + DISTANCE
                            + " inches forward. The robot will go forward and backward continuously"
                            + " along the path. Make sure you have enough room.");
        telemetryA.update();
        initializations();
        follower.followPath(score1);
        bucket = 2;
        gamepad2.setLedColor(255,0,255,999999999);
        gamepad1.setLedColor(255,162,0,999999999);
    }

    /**
     * This runs the OpMode, updating the Follower as well as printing out the debug statements to
     * the Telemetry, as well as the FTC Dashboard.
     */
    @Override
    public void init_loop(){
        arm();
    }
    @Override
    public void loop() {
        follower.update();
        arm();
        armUp();
        spit();
        readyPick();
        autotwist();
        Park();
        if(!follower.isBusy() || follower.atParametricEnd()){
            if(count < 5) {
                if (forward == 1 && bucket == 1) {
                    if (count == 1) {
                        follower.followPath(push1);
                        apress = 1.5;
                        forward = 2;
                    } else if (count == 2) {
                        follower.followPath(push3);
                        apress = 1.5;
                        forward = 2;
                    } else if (count == 3) {
                        follower.followPath(push2);
                        apress = 1.5;
                        forward = 2;
                    } else {
                        forward = 3;
                    }
                    count += 1;
                } else if (forward == 2 && apress == 1 && !limitwrist1.getState()) {
                    follower.followPath(score2);
                    wristpose = .33;
                    twistpose = 0;
                    flippose = .55;
                    slidestarget = 0;
                    bucket = 2;
                    forward = 1;
                }
            }else if(count <= 6){
                if (forward == 3 && bucket == 1) {
                    follower.followPath(comeback2);
                    ypress = 2;
                    forward = 4;
                } else if (forward == 4 && ypress == 1 && !limitwrist1.getState()) {
                    follower.followPath(score3);
                    wristpose = .33;
                    twistpose = 0;
                    flippose = .55;
                    slidestarget = 0;
                    bucket = 2;
                    forward = 3;
                    count += 1;
                }
            }else{
                if (forward == 3 && bucket == 1) {
                    follower.followPath(comeback2);
                    xpress = 2;
                    forward = 4;
                }
            }
        }
    }
    public void initializations(){
        controller = new PIDController(p, i, d);
        armcontroller = new PIDController(armp, armi, armd);
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        slides = hardwareMap.get(DcMotor.class, "slides"); //0 to -3.5 limit
        Arm1 = hardwareMap.get(DcMotor.class, "Arm1");
        Arm2 = hardwareMap.get(DcMotor.class, "Arm2");
        ArmPos = hardwareMap.get(AnalogInput.class, "ArmPos");
        wristencoder = hardwareMap.get(AnalogInput.class, "wristencoder");
        gripspinny = new spin();
        gripspinny.initialize();
        wristy = hardwareMap.get(Servo.class, "wrist");
        twisty = hardwareMap.get(Servo.class, "twist");
        front_left = hardwareMap.get(DcMotor.class, "front_left");
        front_right = hardwareMap.get(DcMotor.class, "front_right");
        rear_left = hardwareMap.get(DcMotor.class, "rear_left");
        rear_right = hardwareMap.get(DcMotor.class, "rear_right");
        limitwrist1 = hardwareMap.get(DigitalChannel.class, "limitwrist1");
        limitfront = hardwareMap.get(RevTouchSensor.class, "limitfront");
        limitfront2 = hardwareMap.get(RevTouchSensor.class, "limitfront2");
        light = hardwareMap.get(Servo.class, "light");
        gripspinny.setPower(0);
        slides.setDirection(DcMotor.Direction.REVERSE);
        slides.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        slides.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        Arm1 .setDirection(DcMotor.Direction.REVERSE);
        Arm1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        Arm2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        front_left.setDirection(DcMotor.Direction.REVERSE);
        front_right.setDirection(DcMotor.Direction.FORWARD);
        rear_left.setDirection(DcMotor.Direction.REVERSE);
        rear_right.setDirection(DcMotor.Direction.FORWARD);
        front_left.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        front_right.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rear_left.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rear_right.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        armtarget = 0;
        slidestarget = 0;
        wristpose = .8;
        flippose = .235;
        twistpose = 0;
    }
    public void arm(){
        toplimit = 1406;
        wrist_at = abs(1 - wristencoder.getVoltage() / 3.3) + .013;
        controller.setPID(p, i, d);
        slidesPose = -slides.getCurrentPosition() * 2;
        armd = -slides.getCurrentPosition()/slideticks * .03 / 19.6;
        armf = .001 + -slides.getCurrentPosition()/slideticks * .2 / 19.6;
        double pid = controller.calculate(slidesPose, slidestarget);
        double ff = Math.cos(Math.toRadians(slidestarget)) * f;
        double power = pid + ff;
        if(slidestarget == 0 && slidesPose < 10 && limitslide.getState()){
            slides.setPower(.4);
        }else {
            if(!limitslide.getState() && slidelimit && slidestarget < 20){
                slides.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                slides.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
                slidestarget = 1;
                slidelimit = false;
            }else if(limitslide.getState()){
                slidelimit = true;
            }
            slides.setPower(-power);
        }
        armcontroller.setPID(armp, armi, armd);
        armPose = (1 - ArmPos.getVoltage() - .2) / ticks * armticks;
        double armpid = controller.calculate(armPose, armtarget);
        double armff = Math.cos(Math.toRadians(armtarget)) * armf;
        double armpower = armpid + armff;
        Arm1.setPower(-armpower);
        Arm2.setPower(-armpower);
        flip.setPosition(flippose);
        wristy.setPosition(wristpose - .04);
        twisty.setPosition(twistpose + .028);

    }
    public class flippy{
        public Servo flippy1;
        public Servo flippy2;
        AnalogInput flipencoder;
        public void initialize(){
            flippy1 = hardwareMap.get(Servo.class, "flippy1");
            flippy2 = hardwareMap.get(Servo.class, "flippy2");
            flipencoder = hardwareMap.get(AnalogInput.class, "flipencoder");
        }
        public void setPosition(double pos){
            flippy1.setPosition(pos);
            flippy2.setPosition(pos);
        }
        public double getPosition(){
            return abs(1 - flipencoder.getVoltage() / 3.3) + .03;
        }
    }
    public class spin{
        public CRServo spinny1;
        public CRServo spinny2;
        public void initialize(){
            spinny1 = hardwareMap.get(CRServo.class, "spinny1");
            spinny2 = hardwareMap.get(CRServo.class, "spinny2");
            spinny2.setDirection(DcMotorSimple.Direction.REVERSE);
        }
        public void setPower(double power){
            spinny1.setPower(power);
            spinny2.setPower(power);
        }
        public double getPower(){
            return spinny1.getPower();
        }
    }

    public void armUp(){
        if(bucket == 2){
            if(slidesPose < 30) {
                armtarget = (int) 1800;
                flippose = .55;
                wristpose = .5;
                twistpose = 0.56;
                bucket = 2.5;
            }

        }else if(bucket == 2.5){
            if (abs(armPose - armtarget) < 100) {
                slidestarget = 1608;
            }
            if (abs(armPose - armtarget) < 100 && (abs(slidesPose - slidestarget) < 100 || (abs(slidesPose - slidestarget) < 140 && count > 5))&& slidestarget == 1608) {
                bucket = 3;
            }
        }
        else if(bucket == 3){
            wristpose = .68;
            flippose = .55;
            if(abs(wrist_at - wristpose) < .06) {
                gripspinny.setPower(1);
                bucket = 4;
            }
        }else if(limitwrist1.getState() && bucket == 4){
            drivetime.reset();
            bucket = 5;
        }else if(bucket == 5 && drivetime.time(TimeUnit.MILLISECONDS) > 30){
            bucket = 1;
        }
    }
    public void spit(){
        if(apress == 1.5){
            wristpose = .33;
            if(abs(wrist_at - wristpose) < .03) {
                slidestarget = 0;
            }
            if(count == 4){
                twistpose = .097;
            }else {
                twistpose = 0;
            }
            flippose = .6;
            if(slidesPose < 30 && abs(wrist_at - wristpose) < .03){
                armtarget = 0;
                apress = 2;
            }
        }
        if((apress == 2) && limitwrist1.getState()){

            if(flip.getPosition() > .5 && armPose < 50) {
                if(count == 2 || count == 4){
                    slidestarget = (int) (1300 + (2 *slideticks * 2));
                }else{
                    slidestarget = (int) (1300 + (1 *slideticks * 2));
                }
            }
            if(slidesPose > 400){
                gripspinny.setPower(-1);
            }
            if(abs(slidesPose - slidestarget) < 30 && slidestarget > 1300){
                flippose = .692;
                armtarget = 0;
                apress = 1;
                if(count == 2 || count == 4){
                    wristpose = .33;
                }else {
                    wristpose = .293;
                }
            }
        }
    }
    public void Park(){
        if(xpress == 2) {
            wristpose = .33;
            if (abs(wrist_at - wristpose) < .03) {
                slidestarget = 0;
            }

            if (slidesPose < 30 && abs(wrist_at - wristpose) < .03) {
                armtarget = 0;
                flippose = .375;
                wristpose = .53;
                twistpose = 0;
                xpress = 1;
            }
        }
    }
    public void readyPick(){
        if(ypress == 2){
            wristpose = .33;
            if(abs(wrist_at - wristpose) < .03) {
                slidestarget = 0;
            }
            if(count == 4){
                twistpose = .097;
            }else {
                twistpose = 0;
            }
            flippose = .6;
            if(slidesPose < 30 && abs(wrist_at - wristpose) < .03){
                armtarget = 0;
                light.setPosition(1);
                wristpose = .31;
                twistpose = 0;
                flippose = .56;

                gripspinny.setPower(-1);
                ypress = 3;
            }
        }else if(ypress == 3){
            if(armPose < 20){
                slidestarget = 200;
                ypress = 4;
            }
        }else if(ypress == 4){
            if(follower.atParametricEnd()){
                look = true;
                ypress = 5;
            }
        }
    }
    public void autotwist(){
        if(look) {
            LLResult result = limelight.getLatestResult();
            if(breaak == 1) {
                follower.breakFollowing();
                Constants.fConstants = AltFConstants.class;
                backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX() + 5, follower.getPose().getY() + .01, Point.CARTESIAN)));
                backwards.setConstantHeadingInterpolation(Math.toRadians(-90));
                slidestarget = 1600;
                follower.followPath(backwards);
                breaak = 2;
            }
            double[] pythonOutputs = result.getPythonOutput();
            locked = pythonOutputs[0] >= 1 && (slidesPose > 800 || mode == 2);
            if (locked) {
                mode = 2;
                if(breaak == 3) {
                    drive();
                }
                tx = (pythonOutputs[1])/78 - 4.5; // How far left or right the target is (degrees)
                tx *= 1.2;
                double ty = (pythonOutputs [2])/78 - 4; // How far up or down the target is (degrees)
                double ta = result.getTa() + (ty + 13) * .3514583; // How big the target looks (0%-100% of the image)
                if(abs(ty) > .1 && breaak == 3) {
                    slidestarget = (int) (slidesPose - (ty * slideticks * 2));
                }
                double angle = pythonOutputs[3];
                if(angle < 45 || angle > 135){
                    twistpose = 0;
                }else{
                    twistpose = .28;
                    ty += .6;
                }
                telemetry.addData("Target X", tx);
                telemetry.addData("Target Y", ty);
                telemetry.addData("Target Area", ta);
                telemetry.addData("Orientation", angle);


                ////////////////////////////////////////////////////////////////

                if (breaak == 2) {
                    if(breaak == 2){
                        slidestarget = (int) slidesPose;
                    }
                    follower.breakFollowing();
                    runtime.reset();
                    breaak = 3;
                }
                if(abs(tx) < .7 && abs(ty) < .7 && good == 1){
                    drivetime.reset();
                    good = 2;
                }else if(good == 2 && drivetime.time(TimeUnit.MILLISECONDS) > 200){
                    Constants.fConstants = BucketConstants.class;
                    follower.breakFollowing();
                    flippose = .692;
                    armtarget = 0;
                    wristpose = .31;
                    slidestarget = (int)slidesPose;
                    look = false;
                    locked = false;
                    ypress = 1;
                    drivetime.reset();
                    breaak = 1;
                    good = 1;
                    mode = 1;
                }else if(abs(tx) > .7 || abs(ty) > .7){
                    good = 1;
                }


            } else {
                telemetry.addData("Limelight", "No Targets");
            }

        }
    }
    public void drive(){
        follower.update();
        Pose poseEstimate = follower.getPose();
        double angle = poseEstimate.getHeading();
        double axial = 0;
        double lateral = 0;
        double yaw = 0;
        double power_level = 1;


        //elbow1.setPosition(servo1pose);
        //elbow2.setPosition(servo2pose);

        double leftFrontPower = (axial + lateral + yaw) * power_level;
        double rightFrontPower = (axial - lateral - yaw) * power_level;
        double leftBackPower = (axial - lateral + yaw) * power_level;
        double rightBackPower = (axial + lateral - yaw) * power_level;

        // If the sticks are being used
        double yaw_rad = /*orientation.getYaw(AngleUnit.RADIANS)*/angle + 3.14159 / 2;
        double temp = axial * Math.sin(yaw_rad) + lateral * Math.cos(yaw_rad);
        lateral = -axial * Math.cos(yaw_rad) + lateral * Math.sin(yaw_rad);
        //double temp = axial * Math.cos(yaw_rad) + lateral * Math.sin(yaw_rad);
        //lateral = -axial * Math.sin(yaw_rad) + lateral * Math.cos(yaw_rad);
        axial = temp;
        // Combie the joystick requests for each axis-motion to determine each wheel's power.
        // Set up a variable for each drive wheel to save the power level for telemetry.
        if(tx > 0) {
            if(tx < .7){
                lateral = .1;
            }else {
                lateral = .3;
            }
        }
        else if (tx < 0){
            if(tx > -.7){
                lateral = -.1;
            }else {
                lateral = -.3  ;
            }
        }
        leftFrontPower = (axial + lateral + yaw) * power_level;
        rightFrontPower = (axial - lateral - yaw) * power_level;
        leftBackPower = (axial - lateral + yaw) * power_level;
        rightBackPower = (axial + lateral - yaw) * power_level;
        // Normalize the values so no wheel power exceeds 00%
        // This ensures that the robot maintains the desired motion.
        double max = Math.max(abs(leftFrontPower), abs(rightFrontPower));
        max = Math.max(max, abs(leftBackPower));
        max = Math.max(max, abs(rightBackPower));
        if (max > 1.0) {
            leftFrontPower /= max;
            rightFrontPower /= max;
            leftBackPower /= max;
            rightBackPower /= max;
        }//Arm code Shoulder
        front_left.setPower(leftFrontPower);
        front_right.setPower(rightFrontPower);
        rear_left.setPower(leftBackPower);
        rear_right.setPower(rightBackPower);
    }
}
