package pedroPathing.opmode;

import static java.lang.Math.abs;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.arcrobotics.ftclib.controller.PIDController;
import com.pedropathing.follower.Follower;
import com.pedropathing.pathgen.BezierCurve;
import com.pedropathing.pathgen.BezierLine;
import com.pedropathing.pathgen.Path;
import com.pedropathing.pathgen.PathChain;
import com.pedropathing.pathgen.Point;
import com.pedropathing.util.Constants;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.rev.RevTouchSensor;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.Telemetry;

import java.util.concurrent.TimeUnit;

import pedroPathing.constants.AltFConstants;
import pedroPathing.constants.FConstants;
import pedroPathing.constants.LConstants;

@Config
@Autonomous (name = "Try", group = "AAA", preselectTeleOp = "AutoArmop"
)
public class Try extends OpMode {
    private Telemetry telemetryA;


    public static double DISTANCE = 40;

    private double forward = 1;

    private Follower follower;

    private Path forwards;
    private Path backwards;
    private Path push1;
    private Path push1ish;
    private Path push1ish2;
    private Path push2;
    private Path push2ish;
    private Path push3;
    private Path push3ish;
    private Path score1;
    private Path score2;
    private Path score2ish;
    private Path score3;
    private Path score3ish;
    private Path score4;
    private Path score4ish;
    private Path score5;
    private Path score5ish;
    private Path comeback1;
    private Path comeback1ish;
    private Path score6;
    private Path score6ish;
    private Path score6ish2;
    private Path comeback2ish2;
    private Path comeback3;
    private Path comeback3ish;
    private Path comeback3ish2;
    private PathChain MainCode;
    private PIDController controller;
    private PIDController armcontroller;

    public static double p = 0.004, i = 0, d = 0;

    public static double f = 0.01;

    public static int slidestarget = 0;
    public static double armp = 0.01, armi = 0, armd = 0;

    public static double armf = 0.01;

    public static int armtarget = 0;
    public double a = 0;


    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    private ElapsedTime drivetime = new ElapsedTime();

    private DcMotor slides = null;
    private DcMotor Arm1 = null;
    private DcMotor Arm2 = null;
    private AnalogInput ArmPos = null;
    private Servo wristy = null;
    private Servo twisty = null;
    public spin gripspinny;

    double mode = 1;
    double basketmove =1;
    double slideratio = 2;
    double slideticks = 103.8 * slideratio / 4.75;
    double armticks = 8192 / 360;
    double toplimit = 18.6;

    double bottomlimit = .25;
    private Path comeback2;
    double slidebasket = 1600 ;
    double armbasket = 2000;
    double twistbasket = .5;
    double wristbasket = .6;
    double slidespecimen = .5;
    double armspecimen = 1380 ;
    double wristspecimen = .3;
    double twistspecimen = .5;
    double armspecimenpickup = 60;
    double wristspecimenpickup = .51;
    public AnalogInput wristencoder;
    public double wrist_at = 0;
    double ticks = .002866;
    double xpress = 1;
    public double start = 0;
    public IMU imu = null;
    public DcMotor front_left = null;
    public DcMotor rear_left = null;
    public DcMotor front_right = null;
    public DcMotor rear_right = null;
    public double apress = 1;
    double just = 0;
    public RevTouchSensor limitfront;
    public RevTouchSensor limitfront2;
    public DigitalChannel limitwrist1;
    public double r1press = 1;
    public double armPose = 0;
    double slidesPose = 0;
    double wristpose = .5;
    double twistpose = .5;
    public double count = 1;
    public double flippose = 0;
    public DigitalChannel limitslide;
    public flippy flip;
    public double flipsafe = 1;
    public double dropping = 1;
    public double special_pick = 1;
    public double first_score = 1;
    public double stick = 1;
    public double missed = 0;

    public double safety = 1;
    private Path driveback = null;
    private Path driveback2 = null;
    private Path driveback3 = null;
    public double ymod = 0;


    public double tx = 0;
    public double mod = 0;

    public Limelight3A limelight;

    public boolean locked = false;
    public double ty = 0;
    public boolean breaak = true;
    public boolean look = false;
    public Servo light = null;
    public boolean slidelimit = true;
    public Path forwardish = null;
    public double aapress = 1;
    public double flipsafer = 1;
    public ElapsedTime help = new ElapsedTime();


    /**
     * This initializes the Follower and creates the forward and backward Paths. Additionally, this
     * initializes the FTC Dashboard telemetry.
     */
    @Override
    public void init() {
        Constants.setConstants(FConstants.class, LConstants.class);
        follower = new Follower(hardwareMap);
        flip = new flippy();
        limitslide = hardwareMap.get(DigitalChannel.class, "limitslide");
        backwards = new Path(new BezierLine(new Point(DISTANCE,0, Point.CARTESIAN), new Point(0,0, Point.CARTESIAN)));
        backwards.setConstantHeadingInterpolation(0);
        score1 = new Path(new BezierLine(new Point(0, 0, Point.CARTESIAN), new Point(27, 16, Point.CARTESIAN)));
        score1.setConstantHeadingInterpolation(0);
        score2 = new Path(new BezierCurve(new Point(3, -43, Point.CARTESIAN), new Point(9, -16.2, Point.CARTESIAN), new Point(13.3, -1.4, Point.CARTESIAN), new Point(27.5, 15.4, Point.CARTESIAN)));
        score2.setConstantHeadingInterpolation(0);
        driveback = new Path(new BezierCurve(new Point(26, 16, Point.CARTESIAN), new Point(24.2, 2.8, Point.CARTESIAN), new Point(19.9, -12.3, Point.CARTESIAN), new Point(15, -38, Point.CARTESIAN)));
        driveback.setConstantHeadingInterpolation(0);
        driveback2 = new Path(new BezierLine(new Point(15, -40, Point.CARTESIAN), new Point(14, -43.0001, Point.CARTESIAN)));
        driveback2.setConstantHeadingInterpolation(Math.toRadians(-23));
        push2 = new Path(new BezierLine(new Point(14.5, -43.0001, Point.CARTESIAN), new Point(14.5, -43, Point.CARTESIAN)));
        push2.setConstantHeadingInterpolation(Math.toRadians(23));
        push3 = new Path(new BezierLine(new Point(14, -43.0001, Point.CARTESIAN), new Point(14.5, -43, Point.CARTESIAN)));
        push3.setConstantHeadingInterpolation(Math.toRadians(0));
        forwards = new Path(new BezierLine(new Point(27,16, Point.CARTESIAN), new Point(26, 15.125, Point.CARTESIAN)));
        forwards.setConstantHeadingInterpolation(0);
        forwardish = new Path(new BezierLine(new Point(14,-43, Point.CARTESIAN), new Point(4,-43, Point.CARTESIAN)));
        forwardish.setConstantHeadingInterpolation(0);
        comeback1 = new Path(new BezierCurve(new Point(26, 13.3, Point.CARTESIAN), new Point(23.2, 5, Point.CARTESIAN), new Point(18.9, -15.3, Point.CARTESIAN), new Point(11, -18, Point.CARTESIAN)));
        comeback1.setConstantHeadingInterpolation(0);
        comeback1ish = new Path(new BezierCurve(new Point(11, -18, Point.CARTESIAN), new Point(6, -18.5, Point.CARTESIAN), new Point(2.5, -18.5, Point.CARTESIAN)));
        comeback1ish.setConstantHeadingInterpolation(0);
        comeback2 = new Path(new BezierCurve(new Point(28, 15.4, Point.CARTESIAN), new Point(23.5, 8, Point.CARTESIAN), new Point(18.9, -12.3, Point.CARTESIAN), new Point(11, -16.8, Point.CARTESIAN)));
        comeback2.setConstantHeadingInterpolation(0);
        score3 = new Path(new BezierCurve(new Point(5.1, -13.9, Point.CARTESIAN), new Point(12.1, -3, Point.CARTESIAN), new Point(14.3, 7, Point.CARTESIAN), new Point(17.3, 11.4, Point.CARTESIAN), new Point(28, 12.1, Point.CARTESIAN)));
        score3.setConstantHeadingInterpolation(0);
        score4 = new Path(new BezierCurve(new Point(2.5, -18.5, Point.CARTESIAN), new Point(12.1, 0, Point.CARTESIAN), new Point(14.3, 12, Point.CARTESIAN), new Point(20.3, 12, Point.CARTESIAN), new Point(27, 13.3, Point.CARTESIAN)));
        score4.setConstantHeadingInterpolation(0);
        follower.followPath(score1);
        telemetryA = new MultipleTelemetry(this.telemetry, FtcDashboard.getInstance().getTelemetry());
        telemetryA.addLine("This will run the robot in a straight line going " + DISTANCE
                + " inches forward. The robot will go forward and backward continuously"
                + " along the path. Make sure you have enough room.");
        telemetryA.update();
        initializations();
    }
    public boolean stuck(){
        boolean x = abs(follower.getPose().getX() - follower.getCurrentPath().getLastControlPoint().getX()) < .1;
        boolean y = abs(follower.getPose().getY() - follower.getCurrentPath().getLastControlPoint().getY()) < .1;
        boolean heading = Math.toDegrees(abs(follower.getPose().getHeading() - follower.getCurrentPath().getHeadingGoal(.6))) < 2;
        return x && y && heading;
    }


    /**
     * This runs the OpMode, updating the Follower as well as printing out the debug statements to
     * the Telemetry, as well as the FTC Dashboard.
     */
    @Override
    public void loop() {
        follower.update();
        if(follower.atParametricEnd() || !follower.isBusy() || follower.isRobotStuck() || stuck()) {
            if(follower.atParametricEnd() && help.time(TimeUnit.MILLISECONDS) > 800){
                help.reset();
            }
            if(forward < 8) {

                if (forward == 1) {
                    follower.followPath(forwards);
                    forward = 3;
                } else if (forward == 3) {
                    follower.followPath(driveback);
                    forward = 4;
                } else if (forward == 4) {
                    Constants.fConstants = AltFConstants.class;
                    follower.followPath(driveback2);
                    forward = 5;
                } else if (forward == 5) {
                        follower.followPath(push3);
                        forward = 6;
                } else if (forward == 6) {
                        follower.followPath(push2);
                        forward = 7;
                } else if (forward == 7) {

                        Constants.fConstants = FConstants.class;
                        follower.followPath(forwardish);
                        forward = 8;
                }
            }else {
                if (forward == 8) {
                    //go to score the second time
                    follower.followPath(score2);
                    //forward = 4.5;
                    forward = 9;
                }
                else if (forward == 9) {
                    //comeback to human player to pick up a block
                    comeback1 = new Path(new BezierCurve(new Point(29, 13.3, Point.CARTESIAN), new Point(16.9, -15.3, Point.CARTESIAN), new Point(11, -19, Point.CARTESIAN)));
                    comeback1.setConstantHeadingInterpolation(0);
                    follower.followPath(comeback1);
                    forward = 10;
                } else if (forward == 10) {
                    //pick block from human player
                    comeback1ish = new Path(new BezierCurve(new Point(11, -19, Point.CARTESIAN), new Point(6, -19, Point.CARTESIAN), new Point(2.5, -19, Point.CARTESIAN)));
                    comeback1ish.setReversed(true);
                    follower.followPath(comeback1ish);
                    forward = 11;
                } else if (forward == 11) {
                    //go to score the block
                    score4 = new Path(new BezierCurve(new Point(2.5, -18.5, Point.CARTESIAN), new Point(12.1, 0, Point.CARTESIAN), new Point(14.3, 12, Point.CARTESIAN), new Point(20.3, 12, Point.CARTESIAN), new Point(27, 13.3, Point.CARTESIAN)));
                    score4.setConstantHeadingInterpolation(0);
                    follower.followPath(score4);
                    forward = 9;
                }
            }
        }
        telemetryA.addData("going forward", follower.isLocalizationNAN());
        telemetryA.addData("going forward", follower.isRobotStuck());
        telemetryA.addData("going forward", follower.atParametricEnd());
        telemetryA.addData("going forward", follower.isBusy());
        telemetryA.addData("going forward", Constants.fConstants);
        follower.telemetryDebug(telemetryA);
    }
    public void initializations(){
        controller = new PIDController(p, i, d);
        armcontroller = new PIDController(armp, armi, armd);
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        light = hardwareMap.get(Servo.class, "light");
        slides = hardwareMap.get(DcMotor.class, "slides"); //0 to -3.5 limit
        Arm1 = hardwareMap.get(DcMotor.class, "Arm1");
        Arm2 = hardwareMap.get(DcMotor.class, "Arm2");
        ArmPos = hardwareMap.get(AnalogInput.class, "ArmPos");
        wristencoder = hardwareMap.get(AnalogInput.class, "wristencoder");
        gripspinny = new spin();
        gripspinny.initialize();
        limelight.setPollRateHz(100); // This sets how often we ask Limelight for data (100 times per second)
        limelight.start(); // This tells Limelight to start looking!
        limelight.pipelineSwitch(0);
        wristy = hardwareMap.get(Servo.class, "wrist");
        twisty = hardwareMap.get(Servo.class, "twist");
        front_left = hardwareMap.get(DcMotor.class, "front_left");
        front_right = hardwareMap.get(DcMotor.class, "front_right");
        rear_left = hardwareMap.get(DcMotor.class, "rear_left");
        rear_right = hardwareMap.get(DcMotor.class, "rear_right");
        limitwrist1 = hardwareMap.get(DigitalChannel.class, "limitwrist1");
        limitfront = hardwareMap.get(RevTouchSensor.class, "limitfront");
        limitfront2 = hardwareMap.get(RevTouchSensor.class, "limitfront2");
        gripspinny.setPower(0);
        slides.setDirection(DcMotor.Direction.REVERSE);
        slides.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        slides.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        Arm1 .setDirection(DcMotor.Direction.REVERSE);
        Arm1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        Arm2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        front_left.setDirection(DcMotor.Direction.REVERSE);
        front_right.setDirection(DcMotor.Direction.FORWARD);
        rear_left.setDirection(DcMotor.Direction.REVERSE);
        rear_right.setDirection(DcMotor.Direction.FORWARD);
        front_left.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        front_right.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rear_left.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rear_right.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        armtarget = 0;
        slidestarget = 0;
        wristpose = .8;
        flippose = .235;
        twistpose = 0;
    }
    public void spit(){
        if((apress == 2) && limitwrist1.getState()){
            if(flippose < .3) {
                wristpose = .33;
                twistpose = 0;
                flippose = .6;
            }
            if(flip.getPosition() > .5) {
                slidestarget = (int) (1300 + (1.3*slideticks * 2));
                if(forward==5 || forward==7){
                    slidestarget += (int) 1.5*slideticks * 2;
                }
            }
            if(slidesPose > 400){
                gripspinny.setPower(-1);
            }
            if(abs(slidesPose - slidestarget) < 20 && slidestarget > 1300){
                flippose = .692;
                armtarget = 0;
                apress = 1;
                if(forward == 5 || forward == 7){
                    wristpose = .33;
                }else {
                    wristpose = .293;
                }
            }
        }
    }
    public void arm(){
        toplimit = 1406;
        wrist_at = abs(1 - wristencoder.getVoltage() / 3.3);
        controller.setPID(p, i, d);
        slidesPose = -slides.getCurrentPosition() * 2;
        armd = -slides.getCurrentPosition()/slideticks * .03 / 19.6;
        armf = .001 + -slides.getCurrentPosition()/slideticks * .2 / 19.6;
        double pid = controller.calculate(slidesPose, slidestarget);
        double ff = Math.cos(Math.toRadians(slidestarget)) * f;
        double power = pid + ff;
        if(slidestarget == 0 && slidesPose < 10 && limitslide.getState()){
            slides.setPower(.4);
        }else {
            if(!limitslide.getState() && slidelimit && slidestarget < 20){
                slides.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                slides.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
                slidestarget = 1;
                slidelimit = false;
            }else if(limitslide.getState()){
                slidelimit = true;
            }
            slides.setPower(-power);
        }
        armcontroller.setPID(armp, armi, armd);
        armPose = (1 - ArmPos.getVoltage() - .2) / ticks * armticks;
        double armpid = controller.calculate(armPose, armtarget);
        double armff = Math.cos(Math.toRadians(armtarget)) * armf;
        double armpower = armpid + armff;
        Arm1.setPower(-armpower);
        Arm2.setPower(-armpower);
        if(a == 1){
            a = 2;
            armtarget = 732;
            slidestarget = 648;
            wristpose = .69;
            twistpose = 0;
            flippose = .651;
            gripspinny.setPower(-1);
        }
        flip.setPosition(flippose);
        wristy.setPosition(wristpose - .04);
        twisty.setPosition(twistpose + .028);


    }
    public class flippy{
        public Servo flippy1;
        public Servo flippy2;
        AnalogInput flipencoder;
        public void initialize(){
            flippy1 = hardwareMap.get(Servo.class, "flippy1");
            flippy2 = hardwareMap.get(Servo.class, "flippy2");
            flipencoder = hardwareMap.get(AnalogInput.class, "flipencoder");
        }
        public void setPosition(double pos){
            flippy1.setPosition(pos);
            flippy2.setPosition(pos);
        }
        public double getPosition(){
            return abs(1 - flipencoder.getVoltage() / 3.3) + .03;
        }
    }
    public class spin{
        public CRServo spinny1;
        public CRServo spinny2;
        public void initialize(){
            spinny1 = hardwareMap.get(CRServo.class, "spinny1");
            spinny2 = hardwareMap.get(CRServo.class, "spinny2");
            spinny2.setDirection(DcMotorSimple.Direction.REVERSE);
        }
        public void setPower(double power){
            spinny1.setPower(power);
            spinny2.setPower(power);
        }
        public double getPower(){
            return spinny1.getPower();
        }
    }
    public void safeflip(){
        if(drivetime.time(TimeUnit.SECONDS) > 300 && flipsafe == 2){
            wristpose = .656;
            slidestarget = 0;
            flippose = .12;
            light.setPosition(0);
            flipsafe = 1;
        }
    }
    public void release(){
        //Waits after dropping the block on the bar and then goes to pick
        if(dropping == 2 && slidesPose < 10) {
            gripspinny.setPower(-1);
            if(special_pick == 2){
                armtarget = 732;
                wristpose = .46;
                slidestarget = 0;
                flippose = .025;
                dropping = 1;
                special_pick = 1;
            }else {
                armtarget = 732;
                wristpose = .43;
                slidestarget = 0;
                flippose = .025;
                flipsafe = 2;
                dropping = 1;
            }
        }
    }
    public void getwall(){
        if(stick == 2 && abs(wristpose - wrist_at) < .05){
            wristpose = .69;
            stick = 1;
        }
    }
    public void afterscore(){
        if(safety == 2){
            drivetime.reset();
            safety = 3;
        }else if(safety == 3 && drivetime.time(TimeUnit.MILLISECONDS) > 300){
            wristpose = .5;
            slidestarget = 0;
            if (count == 5) {
                //used for the last pick to pick the yellow from the wall
                special_pick = 2;
            }
            dropping = 2;
            safety = 1;
        }
    }

    public void autotwist(){
        if(look) {
            LLResult result = limelight.getLatestResult();
            locked = result != null && result.isValid();
            if (locked) {
                tx = result.getTx(); // How far left or right the target is (degrees)
                mod = -tx / 8;
                ty = result.getTy(); // How far up or down the target is (degrees)
                ymod = .20576 * ty;
                slidestarget += ty * 3;
                double ta = result.getTa() + (ty + 13) * .3514583; // How big the target looks (0%-100% of the image)
                String angle = "normal";
                angle = "Too far";
                telemetry.addData("Target X", tx);
                telemetry.addData("Target Y", ty);
                telemetry.addData("Target Area", ta);
                telemetry.addData("Orientation", angle);


                ////////////////////////////////////////////////////////////////


                if(breaak){
                    follower.breakFollowing();
                    slidestarget = (int) slidesPose;
                    Constants.setConstants(AltFConstants.class, LConstants.class);
                    backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN)));
                    backwards.setConstantHeadingInterpolation(0);
                    follower.followPath(backwards);
                    breaak = false;
                }
                else if ((abs(follower.getPose().getY() - follower.getCurrentPath().getLastControlPoint().getY()) < .05 || follower.atParametricEnd() || follower.isRobotStuck()) && (abs(tx) > 2)) {
                    backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX(), follower.getPose().getY() + mod, Point.CARTESIAN)));
                    backwards.setConstantHeadingInterpolation(0);
                    follower.followPath(backwards);
                }else if(abs(tx) < 6 && abs(ty) < 1){
                    Constants.setConstants(FConstants.class, LConstants.class);
                    follower.breakFollowing();
                    flippose = .692;
                    armtarget = 0;
                    wristpose = .31;
                    look = false;
                    locked = false;
                }

            } else {
                telemetry.addData("Limelight", "No Targets");
            }

        }
    }

}

