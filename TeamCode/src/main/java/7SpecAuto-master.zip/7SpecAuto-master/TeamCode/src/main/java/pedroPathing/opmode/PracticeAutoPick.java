package pedroPathing.opmode;
import static java.lang.Math.abs;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.arcrobotics.ftclib.controller.PIDController;
import com.pedropathing.follower.Follower;
import com.pedropathing.follower.FollowerConstants;
import com.pedropathing.localization.Pose;
import com.pedropathing.pathgen.BezierLine;
import com.pedropathing.pathgen.Path;
import com.pedropathing.pathgen.Point;
import com.pedropathing.util.Constants;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.hardware.rev.RevTouchSensor;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.Telemetry;

import java.util.concurrent.TimeUnit;

import pedroPathing.constants.AltFConstants;
import pedroPathing.constants.FConstants;
import pedroPathing.constants.LConstants;

/**
 * This is the StraightBackAndForth autonomous OpMode. It runs the robot in a specified distance
 * straight forward. On reaching the end of the forward Path, the robot runs the backward Path the
 * same distance back to the start. Rinse and repeat! This is good for testing a variety of Vectors,
 * like the drive Vector, the translational Vector, and the heading Vector. Remember to test your
 * tunings on CurvedBackAndForth as well, since tunings that work well for straight lines might
 * have issues going in curves.
 *
 * @author Anyi Lin - 10158 Scott's Bots
 * @author Aaron Yang - 10158 Scott's Bots
 * @author Harrison Womack - 10158 Scott's Bots
 * @version 1.0, 3/12/2024
 */
@Config
@Disabled
@Autonomous (name = "PracticeAutoPick", group = "PIDF Tuning")
public class PracticeAutoPick extends OpMode {
    private Telemetry telemetryA;
    private PIDController controller;
    private PIDController armcontroller;
    public Follower follower;

    public static double p = 0.004, i = 0, d = 0;

    public static double f = 0.01;

    public static int slidestarget = 0;
    public static double armp = 0.01, armi = 0, armd = 0;

    public static double armf = 0.01;

    public static int armtarget = 0;


    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    public double wrist_at;
    public double armPose = 0;
    public AnalogInput wristencoder;

    private DcMotor slides = null;
    private DcMotor Arm1 = null;
    private DcMotor Arm2 = null;
    private AnalogInput ArmPos = null;
    private Servo wristy = null;
    private Servo twisty = null;
    private Servo light = null;

    double mode = 1;
    double county = 2;
    public double basketmove = 1;
    double slideratio = 2;
    double slideticks = 103.8 * slideratio / 4.75;
    double armticks = 8192 / 360;
    double toplimit = 18.6;

    double bottomlimit = .25;
    double slidebasket = 1800;
    double armbasket = 1725;
    double twistbasket = .5;
    double wristbasket = .2;
    double slidespecimen = .5;
    double armspecimen = 1380;
    double wristspecimen = .3;
    double twistspecimen = .5;
    public double tx = 0;
    double armspecimenpickup = 60;
    double wristspecimenpickup = .51;
    double xpress = 1;
    double times = 0;

    public double start = 0;
    public IMU imu = null;
    public DcMotor front_left = null;
    public DcMotor rear_left = null;
    public DcMotor front_right = null;
    public DcMotor rear_right = null;
    public double apress = 1;
    public double flippose = .561;
    double rpress = 1;

    public RevTouchSensor limitfront;
    public RevTouchSensor limitfront2;
    public DigitalChannel limitwrist1;
    public DigitalChannel limitslide;
    public double r1press = 1;
    double press = 1;
    double slidesPose = 0;
    double offset = 0;
    double many = 1;
    double newpos = -312;
    double ypress = 1;
    double check = 1;
    double oldangle = 0;
    double oldtarget = 0;
    double dpress = 1;
    public spin gripspinny;
    public double spit = 1;
    enum State {
        TRAJECTORY_1,   // First, follow a splineTo() trajectory
        TRAJECTORY_2,   // Then, follow a lineTo() trajectory
        // Then we want to do a point turn
        TRAJECTORY_3,   // Then, we follow another lineTo() trajectory
        TRAJECTORY_4,         // Then we're gonna wait a second
        TRAJECTORY_5,         // Finally, we're gonna turn again
        TRAJECTORY_6,
        IDLE            // Our bot will enter the IDLE state when done
    }

    // We define the current state we're on
    // Default to IDLE
    double front = 0;
    public double dropping = 1;
    public double special_pick = 1;
    double scored = 1;

    // Define our start pose
    // This assumes we start at x: 15, y: 10, heading: 180 degrees
    RevHubOrientationOnRobot.LogoFacingDirection logoDirection = RevHubOrientationOnRobot.LogoFacingDirection.LEFT;
    RevHubOrientationOnRobot.UsbFacingDirection usbDirection = RevHubOrientationOnRobot.UsbFacingDirection.UP;

    RevHubOrientationOnRobot orientationOnRobot = new RevHubOrientationOnRobot(logoDirection, usbDirection);
    double just = 0;
    boolean ready = false;
    double aapress = 1;
    ElapsedTime drivetime = new ElapsedTime();
    double ticks = .002866;
    double conversion = ticks * armticks;
    public double inta = 1;
    public flippy flip;
    double wristpose = .5;
    double twistpose = 0;
    double lasttraj = 0;
    double safety = 1;
    double flipsafe = 1;
    boolean auto = false;
    private Path score3;
    private Path score3ish;
    private Path score4;
    private Path score4ish;
    private Path score5;
    private Path score5ish;
    private Path comeback1;
    private Path comeback1ish;
    public double forward = 5;
    public double start_auto = 1;
    public double a = 1;
    boolean slidelimit = true;
    public double yypress = 1;
    public double downish = 1;
    public double scoring = 1;
    public double stick = 1;
    public static double DISTANCE = 40;
    public double ymod = 0;



    private Path forwards;
    private Path backwards;
    public double mod = 0;

    public Limelight3A limelight;

    public boolean locked = false;
    public double ty = 0;
    public boolean breaak = true;
    public boolean look = true;

    /**
     * This initializes the Follower and creates the forward and backward Paths. Additionally, this
     * initializes the FTC Dashboard telemetry.
     */
    @Override
    public void init() {
        controller = new PIDController(p, i, d);
        armcontroller = new PIDController(armp, armi, armd);
        Constants.setConstants(FConstants.class, LConstants.class);
        slides = hardwareMap.get(DcMotor.class, "slides");
        wristy = hardwareMap.get(Servo.class, "wrist");
        twisty = hardwareMap.get(Servo.class, "twist");
        wristencoder = hardwareMap.get(AnalogInput.class, "wristencoder");
        limitwrist1 = hardwareMap.get(DigitalChannel.class, "limitwrist1");
        ArmPos = hardwareMap.get(AnalogInput.class, "ArmPos");
        Arm1 = hardwareMap.get(DcMotor.class, "Arm1");
        Arm2 = hardwareMap.get(DcMotor.class, "Arm2");
        gripspinny = new spin();
        gripspinny.initialize();
        flip = new flippy();
        flip.initialize();
        follower = new Follower(hardwareMap);
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        light = hardwareMap.get(Servo.class, "light");
        limelight.setPollRateHz(100); // This sets how often we ask Limelight for data (100 times per second)
        limelight.start(); // This tells Limelight to start looking!
        limelight.pipelineSwitch(0);
        forwards = new Path(new BezierLine(new Point(0,0, Point.CARTESIAN), new Point(60,0, Point.CARTESIAN)));
        forwards.setConstantHeadingInterpolation(0);
        backwards = new Path(new BezierLine(new Point(0,0, Point.CARTESIAN), new Point(0.01,0, Point.CARTESIAN)));
        backwards.setConstantHeadingInterpolation(0);
        follower.followPath(forwards);
        light.setPosition(1);
        slides.setDirection(DcMotor.Direction.REVERSE);
        slides.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        slides.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        Arm1.setDirection(DcMotor.Direction.REVERSE);
        Arm1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        Arm2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        slidestarget = 800;
        gripspinny.setPower(-1);
        armtarget = 0;
        light.setPosition(1);
        wristpose = .33;
        twistpose = 0;
        flippose = .56;
    }

    @Override
    public void init_loop(){
        arm();
    }

    /**
     * This runs the OpMode, updating the Follower as well as printing out the debug statements to
     * the Telemetry, as well as the FTC Dashboard.
     */
    @Override
    public void loop() {
        follower.update();
        autotwist();
        arm();
        gripspinny.onetwo();
        if(locked) {
            if(breaak){
                follower.breakFollowing();
                Constants.setConstants(AltFConstants.class, LConstants.class);
                backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX() - .5, follower.getPose().getY(), Point.CARTESIAN)));
                backwards.setConstantHeadingInterpolation(0);
                follower.followPath(backwards);
                breaak = false;
            }
            else if ((abs(follower.getPose().getY() - follower.getCurrentPath().getLastControlPoint().getY()) < .05 || follower.atParametricEnd() || follower.isRobotStuck()) && (abs(tx) > 2)) {
                backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX(), follower.getPose().getY() + mod, Point.CARTESIAN)));
                backwards.setConstantHeadingInterpolation(0);
                follower.followPath(backwards);
            }else if(abs(tx) < 4 && abs(ty) < 1){
                flippose = .692;
                armtarget = 0;
                wristpose = .293;
                look = false;
                locked = false;
            }
        }
        if(!limitwrist1.getState() && !breaak){
            slidestarget = 0;
            gripspinny.setPower(0);
            armtarget = 0;
            light.setPosition(1);
            wristpose = .33;
            twistpose = 0;
            flippose = .56;
            breaak = true;
            forwards = new Path(new BezierLine(new Point(follower.getPose().getX(),follower.getPose().getY(), Point.CARTESIAN), new Point(0,0, Point.CARTESIAN)));
            forwards.setConstantHeadingInterpolation(0);
            follower.followPath(forwards);
            Constants.setConstants(FConstants.class, LConstants.class);
        }

    }
    public void autotwist(){
        if(look) {
            LLResult result = limelight.getLatestResult();
            locked = result != null && result.isValid();
            if (locked) {
                tx = result.getTx(); // How far left or right the target is (degrees)
                mod = -tx / 8;
                ty = result.getTy(); // How far up or down the target is (degrees)
                ymod = .20576 * ty;
                slidestarget += ty * 3;
                double ta = result.getTa() + (ty + 13) * .3514583; // How big the target looks (0%-100% of the image)
                String angle = "normal";
                angle = "Too far";
                telemetry.addData("Target X", tx);
                telemetry.addData("Target Y", ty);
                telemetry.addData("Target Area", ta);
                telemetry.addData("Orientation", angle);
            } else {
                telemetry.addData("Limelight", "No Targets");
            }


            ////////////////////////////////////////////////////////////////


            if(breaak){
                follower.breakFollowing();
                Constants.setConstants(AltFConstants.class, LConstants.class);
                backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX() - .5, follower.getPose().getY(), Point.CARTESIAN)));
                backwards.setConstantHeadingInterpolation(0);
                follower.followPath(backwards);
                breaak = false;
            }
            else if ((abs(follower.getPose().getY() - follower.getCurrentPath().getLastControlPoint().getY()) < .05 || follower.atParametricEnd() || follower.isRobotStuck()) && (abs(tx) > .7)) {
                backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX(), follower.getPose().getY() + mod, Point.CARTESIAN)));
                backwards.setConstantHeadingInterpolation(0);
                follower.followPath(backwards);
            }else if(abs(tx) < 4 && abs(ty) < 1){
                flippose = .692;
                armtarget = 0;
                wristpose = .293;
                look = false;
                locked = false;
            }
        }
    }
    public void arm(){
        toplimit = 1406;
        wrist_at = abs(1 - wristencoder.getVoltage() / 3.3);
        controller.setPID(p, i, d);
        slidesPose = -slides.getCurrentPosition() * 2;
        armd = -slides.getCurrentPosition()/slideticks * .03 / 19.6;
        armf = .001 + -slides.getCurrentPosition()/slideticks * .2 / 19.6;
        double pid = controller.calculate(slidesPose, slidestarget);
        double ff = Math.cos(Math.toRadians(slidestarget)) * f;
        double power = pid + ff;
        slides.setPower(-power);
        armcontroller.setPID(armp, armi, armd);
        armPose = (1 - ArmPos.getVoltage() - .2) / ticks * armticks;
        double armpid = controller.calculate(armPose, armtarget);
        double armff = Math.cos(Math.toRadians(armtarget)) * armf;
        double armpower = armpid + armff;
        Arm1.setPower(-armpower);
        Arm2.setPower(-armpower);

        wristy.setPosition(wristpose - .04);
        twisty.setPosition(twistpose + .028);
        flip.setPosition(flippose);

    }

    public class spin{
        public CRServo spinny1;
        public CRServo spinny2;
        public void initialize(){
            spinny1 = hardwareMap.get(CRServo.class, "spinny1");
            spinny2 = hardwareMap.get(CRServo.class, "spinny2");
            spinny2.setDirection(DcMotorSimple.Direction.REVERSE);
        }
        public void onetwo(){
            if(spit == 2){
                drivetime.reset();
                spinny1.setPower(-.4);
                spinny2.setPower(.4);
                spit = 3;
            }else if(spit == 3 && drivetime.time(TimeUnit.MILLISECONDS) > 200){
                drivetime.reset();
                spinny1.setPower(.4);
                spinny2.setPower(-.4);
                spit = 4;
            }else if(spit == 4 && drivetime.time(TimeUnit.MILLISECONDS) > 200){
                spit = 1;
                spinny1.setPower(0);
                spinny2.setPower(0);
            }
        }
        public void setPower(double power){
            spinny1.setPower(power);
            spinny2.setPower(power);
        }

        public double getPower(){
            return spinny1.getPower();
        }
    }


    public class flippy{
        public Servo flippy1;
        public Servo flippy2;
        AnalogInput flipencoder;
        public void initialize(){
            flippy1 = hardwareMap.get(Servo.class, "flippy1");
            flippy2 = hardwareMap.get(Servo.class, "flippy2");
            flipencoder = hardwareMap.get(AnalogInput.class, "flipencoder");
        }
        public void setPosition(double pos){
            flippy1.setPosition(pos);
            flippy2.setPosition(pos);
        }

        public double getPosition(){
            return abs(1 - flipencoder.getVoltage() / 3.3) + .02;
        }
    }
}
