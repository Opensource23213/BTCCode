package pedroPathing.opmode;

import static java.lang.Math.abs;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.arcrobotics.ftclib.controller.PIDController;
import com.pedropathing.follower.Follower;
import com.pedropathing.localization.Pose;
import com.pedropathing.pathgen.BezierCurve;
import com.pedropathing.pathgen.BezierLine;
import com.pedropathing.pathgen.Path;
import com.pedropathing.pathgen.PathChain;
import com.pedropathing.pathgen.Point;
import com.pedropathing.util.Constants;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.rev.RevColorSensorV3;
import com.qualcomm.hardware.rev.RevTouchSensor;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.Telemetry;

import java.util.concurrent.TimeUnit;

import pedroPathing.constants.AltFConstants;
import pedroPathing.constants.BucketConstants;
import pedroPathing.constants.FConstants;
import pedroPathing.constants.LConstants;



@Config
@Autonomous (name = "Six", group = "AAA", preselectTeleOp = "AutoArmop"
)
public class Six extends OpMode {
    private Telemetry telemetryA;


    public static double DISTANCE = 40;

    private double forward = 1;

    private Follower follower;

    private Path forwards;
    private Path backwards;
    private Path push1;
    private Path push1ish;
    private Path push1ish2;
    private Path push2;
    private Path push2ish;
    private Path push3;
    private Path push3ish;
    private Path score1;
    private Path score2;
    private Path score2ish;
    private Path score3;
    private Path score3ish;
    private Path score4;
    private Path score4ish;
    private Path score5;
    private Path score5ish;
    private Path comeback1;
    private Path comeback1ish;
    private Path score6;
    private Path score6ish;
    private Path score6ish2;
    private Path comeback2;
    private Path comeback2ish;
    private Path comeback2ish2;
    private Path comeback3;
    private Path comeback3ish;
    private Path comeback3ish2;
    private PathChain MainCode;
    private PIDController controller;
    private PIDController armcontroller;

    public static double p = 0.004, i = 0, d = 0;

    public static double f = 0.01;

    public static int slidestarget = 0;
    public static double armp = 0.01, armi = 0, armd = 0;

    public static double armf = 0.01;

    public static int armtarget = 0;
    public double a = 0;


    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    private ElapsedTime drivetime = new ElapsedTime();

    public ElapsedTime flasher = new ElapsedTime();

    private DcMotor slides = null;
    private DcMotor Arm1 = null;
    private DcMotor Arm2 = null;
    private AnalogInput ArmPos = null;
    private Servo wristy = null;
    private Servo twisty = null;
    public spin gripspinny;

    double mode = 1;
    double basketmove =1;
    double slideratio = 2;
    double slideticks = 103.8 * slideratio / 4.75;
    double armticks = 8192 / 360;
    double toplimit = 18.6;

    double bottomlimit = .25;
    double slidebasket = 1600 ;
    double armbasket = 2000;
    double twistbasket = .5;
    double wristbasket = .6;
    double slidespecimen = .5;
    double armspecimen = 1380 ;
    double wristspecimen = .3;
    double twistspecimen = .5;
    double armspecimenpickup = 60;
    double wristspecimenpickup = .51;
    public AnalogInput wristencoder;
    public double wrist_at = 0;
    double ticks = .002866;
    double xpress = 1;
    public double start = 0;
    public IMU imu = null;
    public DcMotor front_left = null;
    public DcMotor rear_left = null;
    public DcMotor front_right = null;
    public DcMotor rear_right = null;
    public double apress = 1;
    double just = 0;
    public RevTouchSensor limitfront;
    public RevTouchSensor limitfront2;
    public DigitalChannel limitwrist1;
    public double r1press = 1;
    public double armPose = 0;
    double slidesPose = 0;
    double wristpose = .5;
    double twistpose = .5;
    public double count = 1;
    public double flippose = 0;
    public DigitalChannel limitslide;
    public flippy flip;
    public double flipsafe = 1;
    public double dropping = 1;
    public double special_pick = 1;
    public double first_score = 1;
    public double stick = 1;
    public double missed = 0;

    public double safety = 1;
    private Path driveback = null;
    private Path driveback2 = null;
    private Path plus1 = null;
    public double ymod = 0;


    public double tx = 0;
    public double mod = 0;

    public Limelight3A limelight;

    public boolean locked = false;
    public double ty = 0;
    public double breaak = 1;
    public boolean look = false;
    public Servo light = null;
    public boolean slidelimit = true;
    public Path forwardish = null;
    public double aapress = 1;
    public double flipsafer = 1;
    public double good = 1;
    public double far = 8.5 * slideticks * 2;
    public double right = -8.5;
    public double left = 8.5;
    public double middle = 15.125;
    public double shift = 0;
    public double armadjust = 0;
    public double twistadjust = 0;
    public boolean autotwist = true;
    public String pipeline = "";
    public boolean plus = false;
    public RevColorSensorV3 side = null;



    /**
     * This initializes the Follower and creates the forward and backward Paths. Additionally, this
     * initializes the FTC Dashboard telemetry.
     */
    @Override
    public void init() {
        Constants.setConstants(FConstants.class, LConstants.class);
        follower = new Follower(hardwareMap);
        flip = new flippy();
        limitslide = hardwareMap.get(DigitalChannel.class, "limitslide");
        backwards = new Path(new BezierLine(new Point(DISTANCE,0, Point.CARTESIAN), new Point(0,0, Point.CARTESIAN)));
        backwards.setConstantHeadingInterpolation(0);
        score1 = new Path(new BezierLine(new Point(0, 0, Point.CARTESIAN), new Point(27.5, 16, Point.CARTESIAN)));
        score1.setConstantHeadingInterpolation(0);
        score2 = new Path(new BezierCurve(new Point(3, -43, Point.CARTESIAN), new Point(9, -16.2, Point.CARTESIAN), new Point(13.3, -1.4, Point.CARTESIAN), new Point(27.5, 15.4, Point.CARTESIAN)));
        score2.setConstantHeadingInterpolation(0);
        driveback = new Path(new BezierCurve(new Point(26, 16, Point.CARTESIAN), new Point(24.2, 2.8, Point.CARTESIAN), new Point(19.9, -12.3, Point.CARTESIAN), new Point(15, -38, Point.CARTESIAN)));
        driveback.setConstantHeadingInterpolation(0);
        driveback2 = new Path(new BezierLine(new Point(15, -40, Point.CARTESIAN), new Point(14, -43.0001, Point.CARTESIAN)));
        driveback2.setConstantHeadingInterpolation(Math.toRadians(-23));
        push2 = new Path(new BezierLine(new Point(14.5, -43.0001, Point.CARTESIAN), new Point(14.5, -43, Point.CARTESIAN)));
        push2.setConstantHeadingInterpolation(Math.toRadians(23));
        push3 = new Path(new BezierLine(new Point(14, -43.0001, Point.CARTESIAN), new Point(14.5, -43, Point.CARTESIAN)));
        push3.setConstantHeadingInterpolation(Math.toRadians(0));
        forwards = new Path(new BezierLine(new Point(27,16, Point.CARTESIAN), new Point(26, middle, Point.CARTESIAN)));
        forwards.setConstantHeadingInterpolation(0);
        forwardish = new Path(new BezierLine(new Point(14,-43, Point.CARTESIAN), new Point(4,-43, Point.CARTESIAN)));
        forwardish.setConstantHeadingInterpolation(0);
        comeback1 = new Path(new BezierCurve(new Point(26, 13.3, Point.CARTESIAN), new Point(23.2, 5, Point.CARTESIAN), new Point(18.9, -15.3, Point.CARTESIAN), new Point(11, -18, Point.CARTESIAN)));
        comeback1.setConstantHeadingInterpolation(0);
        comeback1ish = new Path(new BezierCurve(new Point(11, -18, Point.CARTESIAN), new Point(6, -18.5, Point.CARTESIAN), new Point(2.5, -18.5, Point.CARTESIAN)));
        comeback1ish.setConstantHeadingInterpolation(0);
        comeback2ish = new Path(new BezierLine(new Point(11, -17.5, Point.CARTESIAN), new Point(2, -30.5, Point.CARTESIAN)));
        comeback2ish.setConstantHeadingInterpolation(0);
        comeback2 = new Path(new BezierCurve(new Point(28, 15.4, Point.CARTESIAN), new Point(23.5, 8, Point.CARTESIAN), new Point(18.9, -12.3, Point.CARTESIAN), new Point(11, -16.8, Point.CARTESIAN)));
        comeback2.setConstantHeadingInterpolation(0);
        score3 = new Path(new BezierCurve(new Point(1.5, -19, Point.CARTESIAN), new Point(12.1, 0, Point.CARTESIAN), new Point(14.3, 3, Point.CARTESIAN), new Point(23.3, 12, Point.CARTESIAN), new Point(28, 14.2 - (3 * .2), Point.CARTESIAN)));
        score3.setConstantHeadingInterpolation(0);
        score4 = new Path(new BezierCurve(new Point(1.5, -19, Point.CARTESIAN), new Point(12.1, 0, Point.CARTESIAN), new Point(14.3, 3, Point.CARTESIAN), new Point(23.3, 12, Point.CARTESIAN), new Point(28, 14.2 - (4 * .2), Point.CARTESIAN)));
        score4.setConstantHeadingInterpolation(0);
        score5 = new Path(new BezierCurve(new Point(1.5, -19, Point.CARTESIAN), new Point(12.1, 0, Point.CARTESIAN), new Point(14.3, 3, Point.CARTESIAN), new Point(23.3, 12, Point.CARTESIAN), new Point(28, 14.2 - (5 * .2), Point.CARTESIAN)));
        score5.setConstantHeadingInterpolation(0);
        score6 = new Path(new BezierCurve(new Point(1.5, -19, Point.CARTESIAN), new Point(12.1, 0, Point.CARTESIAN), new Point(14.3, 3, Point.CARTESIAN), new Point(23.3, 12, Point.CARTESIAN), new Point(28, 14.2 - (6 * .2), Point.CARTESIAN)));
        score6.setConstantHeadingInterpolation(0);
        score3ish = new Path(new BezierLine(new Point(28, 11.6, Point.CARTESIAN), new Point(31, 15.4, Point.CARTESIAN)));
        score3ish.setConstantHeadingInterpolation(0);
        plus1 = new Path(new BezierLine(new Point(1.5, -19, Point.CARTESIAN), new Point(5, 72, Point.CARTESIAN)));
        plus1.setLinearHeadingInterpolation(0,Math.toRadians(133));
        follower.followPath(score1);
        telemetryA = new MultipleTelemetry(this.telemetry, FtcDashboard.getInstance().getTelemetry());
        gamepad2.setLedColor(255,0,255,999999999);
        gamepad1.setLedColor(255,162,0,999999999);
        flip.initialize();
        initializations();
    }
    @Override
    public void init_loop(){
        arm();
        prematch_telem();
        double what = side.blue();
        if(what > 5000){
            telemetry.addData("Color = ", "Blue");
            limelight.pipelineSwitch(6);
        }else{
            telemetry.addData("Color = ", "Red");
            limelight.pipelineSwitch(5);
        }
    }

    /**
     * This runs the OpMode, updating the Follower as well as printing out the debug statements to
     * the Telemetry, as well as the FTC Dashboard.
     */
    @Override
    public void loop() {
        follower.telemetryDebug(telemetryA);
        if(a == 0){
            a = 1;
        }
        if(first_score == 1){
            if(limitfront.isPressed() || limitfront2.isPressed()){
                gripspinny.setPower(1);
                wristpose = .5;
                slidestarget = 0;
                first_score = 2;
            }
        }
        arm();
        safeflip();
        release();
        getwall();
        afterscore();

        follower.update();
        spit();
        spitter();
        saferflip();
        autotwist();
        if(follower.atParametricEnd() || !follower.isBusy() || (forward == 11 && !limitwrist1.getState()) || (forward == 3 && flasher.time(TimeUnit.MILLISECONDS) > 3000 && flasher.time(TimeUnit.MILLISECONDS) < 4000)) {
            if(forward < 8) {

                if (forward == 1 && (!follower.isBusy() || first_score == 2)) {
                    Constants.fConstants = AltFConstants.class;
                    gripspinny.setPower(1);
                    wristpose = .5;
                    slidestarget = 0;
                    first_score = 2;
                    follower.followPath(forwards);
                    forward = 2;
                } else if (forward == 2) {
                    slidestarget = 0;
                    if (slidesPose < 200) {
                        armtarget = 0;
                        forward = 2.5;
                    }
                    light.setPosition(1);
                    wristpose = .33;
                    twistpose = twistadjust;
                    flippose = .56;
                }
                else if (slidesPose < 40 && armPose < 20 && forward == 2.5) {
                    slidestarget = (int) (700 + armadjust);
                    forward = 2.75;
                }
                else if(abs(slidesPose - slidestarget) < 400 && forward == 2.75){
                    gripspinny.setPower(-1);
                    look = true;
                    flasher.reset();
                    forward = 3;
                }else if (forward == 3 && (!look && ((!limitwrist1.getState() || drivetime.time(TimeUnit.MILLISECONDS) > 400)) || (flasher.time(TimeUnit.MILLISECONDS) > 3000 && flasher.time(TimeUnit.MILLISECONDS) < 4000))) {
                    light.setPosition(0);
                    look = false;
                    locked = false;
                    drivetime.reset();
                    breaak = 1;
                    good = 1;
                    mode = 1;
                    if(flasher.time(TimeUnit.MILLISECONDS) < 3000){
                        flasher.reset();
                    }
                    forward = 3.5;
                } else if(forward == 3.5 && (drivetime.time(TimeUnit.MILLISECONDS) > 200 || flasher.time(TimeUnit.MILLISECONDS) > 3000)){
                    slidestarget = 0;
                    twistpose = 0;
                    flippose = .6;
                    if (slidesPose < 40) {
                        Constants.fConstants = FConstants.class;
                        follower.breakFollowing();
                        driveback = new Path(new BezierCurve(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(24.2, 2.8, Point.CARTESIAN), new Point(19.9, -12.3, Point.CARTESIAN), new Point(15, -38, Point.CARTESIAN)));
                        driveback.setConstantHeadingInterpolation(0);
                        follower.followPath(driveback);
                        flipsafe = 2;
                        drivetime.reset();
                        forward = 4;
                    }
                }else if (forward == 4) {
                    Constants.fConstants = AltFConstants.class;
                    follower.followPath(driveback2);
                    gripspinny.setPower(1);
                    apress = 2;
                    forward = 5;
                } else if (forward == 5 && (!limitwrist1.getState() || drivetime.time(TimeUnit.MILLISECONDS) > 600) && apress == 1) {
                    wristpose = .656;
                    slidestarget = 0;
                    flippose = .12;
                    light.setPosition(0);
                    if (abs(slidesPose - slidestarget) < 40) {
                        gripspinny.setPower(.8);
                        apress = 2;
                        follower.followPath(push3);
                        forward = 6;
                    }
                } else if (forward == 6 && (!limitwrist1.getState() || drivetime.time(TimeUnit.MILLISECONDS) > 600) && apress == 1) {
                    wristpose = .656;
                    slidestarget = 0;
                    flippose = .12;
                    light.setPosition(0);
                    if (abs(slidesPose - slidestarget) < 40) {
                        gripspinny.setPower(.8);
                        apress = 2;
                        follower.followPath(push2);
                        forward = 7;
                    }
                } else if (forward == 7 && (!limitwrist1.getState() || drivetime.time(TimeUnit.MILLISECONDS) > 600) && apress == 1) {
                    armtarget = 732;
                    wristpose = .43;
                    slidestarget = 0;
                    flippose = .025;
                    flipsafer = 2;
                    light.setPosition(0);
                    if (abs(slidesPose - slidestarget) < 30 && abs(flip.getPosition() - flippose) < .1) {
                        aapress = 2;
                        Constants.fConstants = FConstants.class;
                        follower.followPath(forwardish);
                        forward = 8;
                    }
                }
            }else {
                if (forward == 8) {
                    //go to score the second time
                    armtarget = 732;
                    slidestarget = 648;
                    wristpose = .25;
                    twistpose = 0;
                    flippose = .644;
                    stick = 2;
                    count += 1;
                    follower.followPath(score2);
                    //forward = 4.5;
                    forward = 9;
                }
                else if (forward == 9) {
                    //comeback to human player to pick up a block
                    gripspinny.setPower(1);
                    safety = 2;

                    if(count == 6){
                        comeback1 = new Path(new BezierCurve(new Point(30, 13.3, Point.CARTESIAN), new Point(16.9, -15.3, Point.CARTESIAN), new Point(2, -30.5, Point.CARTESIAN)));
                        comeback1.setConstantHeadingInterpolation(0);
                        follower.followPath(comeback1);
                        forward = 20;
                        count = 7;
                    }else{
                        comeback1 = new Path(new BezierCurve(new Point(30, 13.3, Point.CARTESIAN), new Point(16.9, -15.3, Point.CARTESIAN), new Point(11, -18.8, Point.CARTESIAN)));
                        comeback1.setConstantHeadingInterpolation(0);
                        follower.followPath(comeback1);
                        forward = 10;
                    }


                } else if (forward == 10) {
                    //pick block from human player
                    comeback1ish = new Path(new BezierCurve(new Point(11, -18.8, Point.CARTESIAN), new Point(6, -18.8, Point.CARTESIAN), new Point(1.5, -18.8, Point.CARTESIAN)));
                    comeback1ish.setReversed(true);
                    follower.followPath(comeback1ish);
                    forward = 11;

                } else if (forward == 11) {
                    //go to score the block
                    if (count == 6 && plus) {
                        count = 6;
                        follower.followPath(plus1);
                        forward = 25;
                    } else {
                        armtarget = 732;
                        slidestarget = 648;
                        wristpose = .25;
                        twistpose = 0;
                        flippose = .644;
                        stick = 2;
                        count += 1;
                        drivetime.reset();
                        if (count == 3) {
                            follower.followPath(score3);
                        } else if (count == 4) {
                            follower.followPath(score4);
                        } else if (count == 5) {
                            follower.followPath(score5);
                        } else if (count == 6) {
                            follower.followPath(score6);
                        }
                        forward = 9;
                    }
                }else if(forward == 20){
                    follower.followPath(comeback2ish);
                    forward = 21;
                }
            }
        }
        telemetry.addData("going forward", follower.isLocalizationNAN());
        telemetry.addData("going forward", follower.isRobotStuck());
        telemetry.addData("going forward", follower.atParametricEnd());
        telemetry.addData("going forward", follower.isBusy());
        telemetry.addData("going forward", Constants.fConstants);
        telemetry.addData("slide target", slidestarget);
        telemetry.update();
    }
    public boolean stuck(){
        boolean x = abs(follower.getPose().getX() - follower.getCurrentPath().getLastControlPoint().getX()) < .1;
        boolean y = abs(follower.getPose().getY() - follower.getCurrentPath().getLastControlPoint().getY()) < .1;
        boolean heading = Math.toDegrees(abs(follower.getPose().getHeading() - follower.getCurrentPath().getHeadingGoal(.6))) < 2;
        return x && y && heading;
    }
    public void initializations(){
        controller = new PIDController(p, i, d);
        armcontroller = new PIDController(armp, armi, armd);
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        light = hardwareMap.get(Servo.class, "light");
        slides = hardwareMap.get(DcMotor.class, "slides"); //0 to -3.5 limit
        Arm1 = hardwareMap.get(DcMotor.class, "Arm1");
        Arm2 = hardwareMap.get(DcMotor.class, "Arm2");
        ArmPos = hardwareMap.get(AnalogInput.class, "ArmPos");
        wristencoder = hardwareMap.get(AnalogInput.class, "wristencoder");
        side = hardwareMap.get(RevColorSensorV3.class, "color");
        gripspinny = new spin();
        gripspinny.initialize();
        limelight.setPollRateHz(100); // This sets how often we ask Limelight for data (100 times per second)
        limelight.start(); // This tells Limelight to start looking!
        double what = side.blue();
        if(what > 5000){
            telemetry.addData("Color = ", "Blue");
            limelight.pipelineSwitch(6);
        }else{
            telemetry.addData("Color = ", "Red");
            limelight.pipelineSwitch(5);
        }
        wristy = hardwareMap.get(Servo.class, "wrist");
        twisty = hardwareMap.get(Servo.class, "twist");
        front_left = hardwareMap.get(DcMotor.class, "front_left");
        front_right = hardwareMap.get(DcMotor.class, "front_right");
        rear_left = hardwareMap.get(DcMotor.class, "rear_left");
        rear_right = hardwareMap.get(DcMotor.class, "rear_right");
        limitwrist1 = hardwareMap.get(DigitalChannel.class, "limitwrist1");
        limitfront = hardwareMap.get(RevTouchSensor.class, "limitfront");
        limitfront2 = hardwareMap.get(RevTouchSensor.class, "limitfront2");
        gripspinny.setPower(0);
        slides.setDirection(DcMotor.Direction.REVERSE);
        slides.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        slides.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        Arm1 .setDirection(DcMotor.Direction.REVERSE);
        Arm1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        Arm2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        front_left.setDirection(DcMotor.Direction.REVERSE);
        front_right.setDirection(DcMotor.Direction.FORWARD);
        rear_left.setDirection(DcMotor.Direction.REVERSE);
        rear_right.setDirection(DcMotor.Direction.FORWARD);
        front_left.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        front_right.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rear_left.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rear_right.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        armtarget = 0;
        slidestarget = 0;
        wristpose = .8;
        flippose = .235;
        twistpose = 0;
    }
    public void saferflip(){
        if(flipsafer == 2 && flip.getPosition() < .45){
            twistpose = .56;
            flipsafer = 1;
        }
    }
    public void spit(){
        if((apress == 2) && limitwrist1.getState()){
            if(flippose < .3) {
                wristpose = .33;
                if(forward == 7){
                    twistpose = .097;
                }else {
                    twistpose = 0;
                }
                flippose = .6;
            }
            if(flip.getPosition() > .5) {
                slidestarget = (int) (1300 + (1.3*slideticks * 2));
                if(forward==5 || forward==7){
                    slidestarget += (int) 1.5*slideticks * 2;
                    if(forward == 7){
                        slidestarget -= (int) .3*slideticks * 2;
                    }
                }
            }
            if(slidesPose > 400){
                gripspinny.setPower(-1);
            }
            if(abs(slidesPose - slidestarget) < 40 && slidestarget > 1300){
                flippose = .692;
                armtarget = 0;
                drivetime.reset();
                apress = 1;
                if(forward == 5 || forward == 7){
                    wristpose = .33;
                }else {
                    wristpose = .293;
                }
            }
        }
    }
    public void arm(){
        toplimit = 1406;
        wrist_at = abs(1 - wristencoder.getVoltage() / 3.3) + .013;
        controller.setPID(p, i, d);
        slidesPose = -slides.getCurrentPosition() * 2;
        armd = -slides.getCurrentPosition()/slideticks * .03 / 19.6;
        armf = .001 + -slides.getCurrentPosition()/slideticks * .2 / 19.6;
        double pid = controller.calculate(slidesPose, slidestarget);
        double ff = Math.cos(Math.toRadians(slidestarget)) * f;
        double power = pid + ff;
        if(slidestarget == 0 && slidesPose < 10 && limitslide.getState()){
            slides.setPower(.4);
        }else {
            if(!limitslide.getState() && slidelimit && slidestarget < 20){
                slides.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                slides.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
                slidestarget = 10;
                slidelimit = false;
            }else if(limitslide.getState()){
                slidelimit = true;
            }
            slides.setPower(-power);
        }
        armcontroller.setPID(armp, armi, armd);
        armPose = (1 - ArmPos.getVoltage() - .2) / ticks * armticks;
        double armpid = controller.calculate(armPose, armtarget);
        double armff = Math.cos(Math.toRadians(armtarget)) * armf;
        double armpower = armpid + armff;
        Arm1.setPower(-armpower);
        Arm2.setPower(-armpower);
        if(a == 1){
            a = 2;
            armtarget = 732;
            slidestarget = 648;
            wristpose = .69;
            twistpose = 0;
            flippose = .644;
            gripspinny.setPower(-1);
        }
        flip.setPosition(flippose);
        wristy.setPosition(wristpose - .04);
        twisty.setPosition(twistpose + .028);


    }
    public class flippy{
        public Servo flippy1;
        public Servo flippy2;
        AnalogInput flipencoder;
        public void initialize(){
            flippy1 = hardwareMap.get(Servo.class, "flippy1");
            flippy2 = hardwareMap.get(Servo.class, "flippy2");
            flipencoder = hardwareMap.get(AnalogInput.class, "flipencoder");
        }
        public void setPosition(double pos){
            flippy1.setPosition(pos);
            flippy2.setPosition(pos);
        }
        public double getPosition(){
            return abs(1 - flipencoder.getVoltage() / 3.3) + .03;
        }
    }
    public class spin{
        public CRServo spinny1;
        public CRServo spinny2;
        public void initialize(){
            spinny1 = hardwareMap.get(CRServo.class, "spinny1");
            spinny2 = hardwareMap.get(CRServo.class, "spinny2");
            spinny2.setDirection(DcMotorSimple.Direction.REVERSE);
        }
        public void setPower(double power){
            spinny1.setPower(power);
            spinny2.setPower(power);
        }
        public double getPower(){
            return spinny1.getPower();
        }
    }
    public void safeflip(){
        if(drivetime.time(TimeUnit.MILLISECONDS) > 800 && flipsafe == 2){
            wristpose = .656;
            slidestarget = 0;
            flippose = .12;
            light.setPosition(0);
            flipsafe = 3;
        }else if(flipsafe == 3 && abs(flip.getPosition() - flippose) < .15){
            gripspinny.setPower(1);
            flipsafe = 1;
        }
    }
    public void release(){
        //Waits after dropping the block on the bar and then goes to pick
        if(dropping == 2 && drivetime.time(TimeUnit.MILLISECONDS) > 300) {
            if(special_pick == 2 && drivetime.time(TimeUnit.MILLISECONDS) > 400){
                wristpose = .33;
                twistpose = 0;
                flippose = .56;
                armtarget = 0;
                slidestarget = 0;
                dropping = 1;
                special_pick = 1;
            }else if(special_pick != 2){
                armtarget = 732;
                wristpose = .43;
                slidestarget = 0;
                flippose = .025;
                gripspinny.setPower(-1);
                flipsafer = 2;
                dropping = 1;
            }
        }
    }
    public void getwall(){
        if(stick == 2 && drivetime.time(TimeUnit.MILLISECONDS) > 200){
            wristpose = .69;
            stick = 1;
        }
    }
    public void afterscore(){
        if(safety == 2) {
            wristpose = .5;
            slidestarget = 0;
            if(count == 7){
                special_pick = 2;
            }
            drivetime.reset();
            dropping = 2;
            safety = 1;
        }
    }

    public void autotwist(){
        if(look) {
            LLResult result = limelight.getLatestResult();
            if(breaak == 1) {
                follower.breakFollowing();
                Constants.fConstants = AltFConstants.class;
                backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(27, follower.getPose().getY(), Point.CARTESIAN)));
                backwards.setConstantHeadingInterpolation(0);
                follower.followPath(backwards);
                breaak = 2;
            }
            if(follower.getPose().getX() > 26 && breaak == 2) {
                follower.breakFollowing();
                Constants.fConstants = AltFConstants.class;
                backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(29, follower.getPose().getY() + shift, Point.CARTESIAN)));
                backwards.setConstantHeadingInterpolation(0);
                follower.followPath(backwards);
                breaak = 2.5;
            }
            double[] pythonOutputs = result.getPythonOutput();
            locked = pythonOutputs[0] >= 1 && ((follower.getPose().getX() > 28) || mode == 2);
            if (locked) {
                mode = 2;
                tx = (pythonOutputs[1])/78 - 4.5; // How far left or right the target is (degrees)
                double ty = (pythonOutputs [2])/78 - 4; // How far up or down the target is (degrees)
                double ta = result.getTa() + (ty + 13) * .3514583; // How big the target looks (0%-100% of the image)

                double angle = pythonOutputs[3];
                if(angle < 45 || angle > 135){
                    twistpose = 0;
                }else{
                    twistpose = .28;
                    ty += .6;
                }
                if(abs(ty) > .1 && breaak == 3) {
                    slidestarget = (int) (slidesPose - (ty * slideticks * 2));
                }
                telemetry.addData("Target X", tx);
                telemetry.addData("Target Y", ty);
                telemetry.addData("Target Area", ta);
                telemetry.addData("Orientation", angle);


                ////////////////////////////////////////////////////////////////

                if ((abs(follower.getPose().getY() - follower.getCurrentPath().getLastControlPoint().getY()) <= .7  || follower.atParametricEnd() || follower.isRobotStuck() || breaak == 2.5)) {
                    Constants.fConstants = BucketConstants.class;
                    follower.breakFollowing();
                    if(tx < 0) {
                        if(tx > -1){
                            backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX(), follower.getPose().getY() - tx, Point.CARTESIAN)));
                        }else {
                            backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX(), follower.getPose().getY() - Math.pow(abs(tx), .5) * -1, Point.CARTESIAN)));
                        }
                    }else{
                        if(tx < 1){
                            backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX(), follower.getPose().getY() - tx, Point.CARTESIAN)));
                        }else {
                            backwards = new Path(new BezierLine(new Point(follower.getPose().getX(), follower.getPose().getY(), Point.CARTESIAN), new Point(follower.getPose().getX(), follower.getPose().getY() - Math.pow(tx, .5), Point.CARTESIAN)));

                        }

                    }
                    backwards.setConstantHeadingInterpolation(0);
                    if(breaak == 2.5){
                        flasher.reset();
                        slidestarget = (int) slidesPose;
                    }
                    breaak = 3;
                    follower.followPath(backwards);
                }
                if(abs(tx) < .7 && abs(ty) < .7 && good == 1){
                    drivetime.reset();
                    good = 2;
                }if(good == 2 && drivetime.time(TimeUnit.MILLISECONDS) > 200){
                    Constants.fConstants = FConstants.class;
                    follower.breakFollowing();
                    flippose = .692;
                    armtarget = 0;
                    wristpose = .31;
                    slidestarget = (int)slidesPose;
                    light.setPosition(0);
                    look = false;
                    locked = false;
                    drivetime.reset();
                    breaak = 1;
                    good = 1;
                    mode = 1;
                }else if(abs(tx) > .7 || abs(ty) > .7){
                    good = 1;
                }


            } else {
                telemetry.addData("Limelight", "No Targets");
            }

        }
    }
    public void drive(){
        follower.update();
        Pose poseEstimate = follower.getPose();
        double angle = poseEstimate.getHeading();
        double axial = 0;
        double lateral = 0;
        double yaw = 0;
        double power_level = 1;


        //elbow1.setPosition(servo1pose);
        //elbow2.setPosition(servo2pose);

        double leftFrontPower = (axial + lateral + yaw) * power_level;
        double rightFrontPower = (axial - lateral - yaw) * power_level;
        double leftBackPower = (axial - lateral + yaw) * power_level;
        double rightBackPower = (axial + lateral - yaw) * power_level;

        // If the sticks are being used
        double yaw_rad = /*orientation.getYaw(AngleUnit.RADIANS)*/angle + 3.14159 / 2;
        double temp = axial * Math.sin(yaw_rad) + lateral * Math.cos(yaw_rad);
        lateral = -axial * Math.cos(yaw_rad) + lateral * Math.sin(yaw_rad);
        //double temp = axial * Math.cos(yaw_rad) + lateral * Math.sin(yaw_rad);
        //lateral = -axial * Math.sin(yaw_rad) + lateral * Math.cos(yaw_rad);
        axial = temp;
        // Combie the joystick requests for each axis-motion to determine each wheel's power.
        // Set up a variable for each drive wheel to save the power level for telemetry.
        if(tx > 0) {
            if(tx < .7){
                lateral = .1;
            }else {
                lateral = .3;
            }
        }
        else if (tx < 0){
            if(tx > -.7){
                lateral = -.1;
            }else {
                lateral = -.3;
            }
        }
        leftFrontPower = (axial + lateral + yaw) * power_level;
        rightFrontPower = (axial - lateral - yaw) * power_level;
        leftBackPower = (axial - lateral + yaw) * power_level;
        rightBackPower = (axial + lateral - yaw) * power_level;
        // Normalize the values so no wheel power exceeds 00%
        // This ensures that the robot maintains the desired motion.
        double max = Math.max(abs(leftFrontPower), abs(rightFrontPower));
        max = Math.max(max, abs(leftBackPower));
        max = Math.max(max, abs(rightBackPower));
        if (max > 1.0) {
            leftFrontPower /= max;
            rightFrontPower /= max;
            leftBackPower /= max;
            rightBackPower /= max;
        }//Arm code Shoulder
        front_left.setPower(leftFrontPower);
        front_right.setPower(rightFrontPower);
        rear_left.setPower(leftBackPower);
        rear_right.setPower(rightBackPower);
    }
    public void spitter(){
        if(aapress == 2){
            runtime = new ElapsedTime();
            aapress = 3;
        }else if(aapress == 3 && runtime.time(TimeUnit.MILLISECONDS) < 300){
            gripspinny.setPower(1);
        }else if(aapress == 3){
            gripspinny.setPower(-1);
            aapress = 1;
        }
    }
    public void prematch_telem(){
        if(gamepad1.a){
            limelight.pipelineSwitch(6);
            pipeline = "BLUE";
        }
        else if(gamepad1.b){
            limelight.pipelineSwitch(5);
            pipeline = "RED";
        }
        if(gamepad1.dpad_left){
            shift = left;
        }
        else if(gamepad1.dpad_right){
            shift = right;
        }
        else if(gamepad1.dpad_down){
            shift = 0;
        }
        if(gamepad2.dpad_up){
            armadjust = far;
        }
        else if(gamepad2.dpad_down){
            armadjust = 0;
        }
        else if(gamepad2.dpad_left){
            twistadjust = .28;
            autotwist = false;
        }
        else if(gamepad2.dpad_right){
            twistadjust = 0;
            autotwist = false;
        }
        else if(gamepad2.a){
            twistadjust = 0;
            autotwist = true;
        }
        telemetry.addLine("You are on the " + pipeline + " side!");
        telemetry.addLine();
        if(shift == left){
            telemetry.addLine("The robot will shift to the LEFT!");
        }
        else if(shift == right){
            telemetry.addLine("The robot will shift to the RIGHT!");
        }
        else if(shift == 0){
            telemetry.addLine("The robot won't shift at all!");
        }
        telemetry.addLine();
        if(armadjust == far){
            telemetry.addLine("The designated block is FAR!");
        }
        else if(armadjust == 0){
            telemetry.addLine("The designated block is NEAR!");
        }
        telemetry.addLine();
        telemetry.addLine("The gripper will AUTOMATICALLY twist!");
        telemetry.addLine();
        telemetry.addLine("Good Luck");
        telemetry.update();
    }


}

